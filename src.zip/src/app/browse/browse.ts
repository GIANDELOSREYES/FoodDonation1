import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Firestore, collection, collectionData, doc, deleteDoc, updateDoc } from '@angular/fire/firestore';


@Component({
  selector: 'app-browse',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './browse.html',
  styleUrls: ['./browse.css']
})
export class Browse {

  donations: any[] = []
  donationIdToEdit = signal<string | null>(null);

  // Edit fields (same as before)
  foodEdit = signal('');
  descriptionEdit = signal('');
  quantityEdit = signal('');
  bestByDateEdit = signal<string | null>(null);
  pickupLocationEdit = signal('');
  donorNameEdit = signal('');
  contactInformationEdit = signal('');

  // Claim fields
  claimId = signal<string | null>(null);
  recipientName = signal('');

  constructor(private firestore: Firestore) {
    const donationsCollection = collection(this.firestore, 'donations');
    collectionData(donationsCollection, { idField: 'id' })
      .subscribe(data => {
        this.donations = data;
      });
  }

  // DELETE 
  deleteDonation(id: string) {
    const donationDoc = doc(this.firestore, `donations/${id}`);
    deleteDoc(donationDoc);
  }

  // START EDIT
  startEditDonation(donation: any) {
    this.donationIdToEdit.set(donation.id);
    this.foodEdit.set(donation.food || '');
    this.descriptionEdit.set(donation.description || '');
    this.quantityEdit.set(donation.quantity || '');

    if (donation.bestByDate) {
      const dateObj = new Date(donation.bestByDate);
      if (!isNaN(dateObj.getTime())) {
        const yyyy = dateObj.getFullYear();
        const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
        const dd = String(dateObj.getDate()).padStart(2, '0');
        this.bestByDateEdit.set(`${yyyy}-${mm}-${dd}`);
      } else {
        this.bestByDateEdit.set(donation.bestByDate);
      }
    } else {
      this.bestByDateEdit.set(null);
    }

    this.pickupLocationEdit.set(donation.pickupLocation || '');
    this.donorNameEdit.set(donation.donorName || '');
    this.contactInformationEdit.set(donation.contactInformation || '');
  }

  // SAVE EDITED DONATION
  async saveEditedDonation() {
    const id = this.donationIdToEdit();
    if (!id) return;

    const donationDoc = doc(this.firestore, `donations/${id}`);

    await updateDoc(donationDoc, {
      food: this.foodEdit(),
      description: this.descriptionEdit(),
      quantity: this.quantityEdit(),
      bestByDate: this.bestByDateEdit(),
      pickupLocation: this.pickupLocationEdit(),
      donorName: this.donorNameEdit(),
      contactInformation: this.contactInformationEdit()

    });

    this.donationIdToEdit.set(null);
  }

  // BEGIN CLAIM PROCESS
  startClaim(id: string) {
    this.claimId.set(id);
    this.recipientName.set('');
  }

  // COMPLETE CLAIM PROCESS
  async confirmClaim(donation: any) {
    const id = this.claimId();
    if (!id) return;

    const donationDoc = doc(this.firestore, `donations/${id}`);

    donation.isClaimed = true;



    await updateDoc(donationDoc, {
      status: 'claimed',
      recipient: this.recipientName(),
      isClaimed: donation.isClaimed
    });






    this.claimId.set(null);
    this.claimId.set(null);
    this.recipientName.set('');
  }
}
