import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Firestore, collection, collectionData, doc, deleteDoc, updateDoc, addDoc} from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.html',
  styleUrls: ['./admin.css']
})
export class Admin {

  inputUsername: string = "";
  inputPassword: string = "";

  hasLoggedIn: boolean = false;

  username: string = "admin";
  password: string = "password";

  donations = signal<any[]>([]);

  stats = signal({
    total: 0,
    available: 0,
    claimed: 0,
    completed: 0
  });

  constructor(private firestore: Firestore) {
    const savedLoginState = sessionStorage.getItem('adminLoggedIn');
    if (savedLoginState === 'true') {
      this.hasLoggedIn = true;
    }

    const donationsCollection = collection(this.firestore, 'donations');
    collectionData(donationsCollection, { idField: 'id' })
      .subscribe((data: any[]) => {

        this.donations.set(data);

        // treat missing status as 'available'
        const total = data.length;
        const available = data.filter(d => (d.status ?? 'available') === 'available').length;
        const claimed = data.filter(d => (d.status ?? '') === 'claimed').length;
        const completed = data.filter(d => (d.status ?? '') === 'completed').length;

        this.stats.set({
          total,
          available,
          claimed,
          completed
        });
      });
  }

  deleteDonation(id: string) {
    const donationDoc = doc(this.firestore, `donations/${id}`);
    deleteDoc(donationDoc);
  }

  async approveDonation(donation: any){


    const approved = donation.isApproved = true;

    const id = donation.id;

    const donationDoc = doc(this.firestore, `donations/${id}`);

    await updateDoc(donationDoc, {
      isApproved: approved
    });

  }

   checkLogIn(){

    if(this.inputUsername === this.username && this.inputPassword === this.password){
      this.hasLoggedIn = true;
      sessionStorage.setItem('adminLoggedIn', 'true');
      alert("Login successful!");
    }else{
      alert("Incorrect username or password. Please try again.");
    }
  }

  logout(){
    this.hasLoggedIn = false;
    sessionStorage.setItem('adminLoggedIn', 'false');
  }



}
