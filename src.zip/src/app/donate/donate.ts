import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Firestore, collection, collectionData, addDoc, doc, deleteDoc, updateDoc } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-donate',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './donate.html',
  styleUrls: ['./donate.css']
})
export class Donate {

  title = signal('Food Donation Posting – Food4Baguio');

  // INPUT SIGNALS
  food = signal('');
  description = signal('');
  quantity = signal<number | null>(null);
  bestByDate = signal('');
  pickupLocation = signal('');
  donorName = signal('');
  contactInformation = signal('');
  photoPreview = signal<string | null>(null);

  donations: any[] = [];

  constructor(private firestore: Firestore) {
    const donationsCollection = collection(this.firestore, 'donations');
    collectionData(donationsCollection, { idField: 'id' })
      .subscribe(data => {
        this.donations = data;
      });
  }

  // ADD DOCUMENT
  async onSubmit() {
    const donationsCollection = collection(this.firestore, 'donations');

    const donation = {
      food: this.food(),
      description: this.description(),
      quantity: this.quantity(),
      bestByDate: this.bestByDate(),
      pickupLocation: this.pickupLocation(),
      donorName: this.donorName(),
      contactInformation: this.contactInformation(),
      photoUrl: this.photoPreview(),
      isClaimed: false,
      isApproved: false,

      status: 'available',                 
      date: new Date().toISOString()       
    };

    await addDoc(donationsCollection, donation);

    // reset signals
    this.food.set('');
    this.description.set('');
    this.quantity.set(null);
    this.bestByDate.set('');
    this.pickupLocation.set('');
    this.donorName.set('');
    this.contactInformation.set('');
    this.photoPreview.set(null);

    alert('Donation submitted successfully!');
  }


  // HANDLE FILE SELECTION
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.photoPreview.set(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  }

  // DELETE DOCUMENT
  deleteDonation(id: string) {
    const donationDoc = doc(this.firestore, `donations/${id}`);
    deleteDoc(donationDoc);
  }

  // UPDATE DOCUMENT
  updateDonation(id: string, updatedData: any) {
    const donationDoc = doc(this.firestore, `donations/${id}`);
    updateDoc(donationDoc, updatedData);
  }
}
