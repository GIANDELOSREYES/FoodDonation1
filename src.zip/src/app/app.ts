import { Component, signal } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  protected readonly title = signal('FoodDonation');
 
  get adminLoggedIn() {
    return sessionStorage.getItem('adminLoggedIn') === 'true';
  }

  logoutAdmin() {
    sessionStorage.setItem('adminLoggedIn', 'false');
    window.location.reload();
  }


}