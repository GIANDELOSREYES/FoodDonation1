import { Routes } from '@angular/router';
import { Donate } from './donate/donate';
import { Admin } from './admin/admin';
import { Browse } from './browse/browse';

export const routes: Routes = [

    {path: 'donate', component: Donate},
    {path: 'admin', component: Admin},
    {path: 'browse', component: Browse},
    {path: '', redirectTo: 'donate', pathMatch: 'full' }
];